!function ($) {

$.plAdmin = {


}

}(window.jQuery);