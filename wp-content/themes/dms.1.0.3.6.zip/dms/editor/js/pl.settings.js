!function ($) {

	$.plSettings = {



	}

}(window.jQuery);