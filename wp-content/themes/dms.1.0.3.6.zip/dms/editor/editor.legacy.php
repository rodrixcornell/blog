<?php
/**
 *
 *
 *  PageLines Legacy Upgrading Class
 *
 *
 *  @package PageLines DMS
 *  @since 3.0.0
 *
 *
 */
class EditorLegacy {

}
