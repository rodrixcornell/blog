<?php

// Internal build versions.


$platform_build = '1.0.3.6';

$free_build = '1.0.3.6';