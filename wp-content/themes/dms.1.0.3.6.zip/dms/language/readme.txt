********************************************************

	PageLines I18n
	==============
	
	Join our translation task force at
	www.transifex.com/projects/p/pagelines-dms/

********************************************************
