<?php
/*
Template Name: Template | 4
*/

/**
 * Page Template - DELTA
 *
 * @package     PageLines Framework
 * @since       ...
 *
 * @link        http://www.pagelines.com/
 * @link        http://www.pagelines.com/DMS
 *
 * @author      PageLines   http://www.pagelines.com/
 * @copyright   Copyright (c) 2008-2012, PageLines  hello@pagelines.com
 *
 * @internal    last revised January 20, 2012
 * @version     ...
 *
 * @todo Define version
 */

setup_pagelines_template();