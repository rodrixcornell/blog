
Menu supports only one level of links. 

By default custom header is not displayed. To display custom header please select "I Want to use custom header" in "Header settings" tab of theme options page.

-----------------------------------------

Bizantine WordPress Theme, Copyright 2013 ThemeAlley.com
Bizantine is distributed under the terms of the GNU GPL v2




Install Steps:
--------------

1. Activate the theme
2. Go to the Theme Option page
3. Setup theme options



------------------------------------------

Social Icons and all other images made by ThemeAlley.com and licensed as GPLv2

TinyNav license : MIT License http://tinynav.viljamis.com

Respond.js license : MIT/GPLv2 Lic. j.mp/respondjs

TitilliumText font license : http://www.fontsquirrel.com/license/TitilliumText

Chunkfive font license : http://www.fontsquirrel.com/license/ChunkFive

NObile font license : http://www.fontsquirrel.com/license/Nobile


-------------------------------------------

