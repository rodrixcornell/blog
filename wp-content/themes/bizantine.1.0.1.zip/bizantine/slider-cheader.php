    <div id="feature" class="site-slider">
    
    	<div class="responsive-container">
        
        	<div class="site-slider-custom-header">
        
        		<img src="<?php header_image(); ?>" height="<?php echo get_custom_header()->height; ?>" width="<?php echo get_custom_header()->width; ?>" alt="" />

    		</div><!-- .site-slider-custom-header --> 
                
    	</div><!-- #Responsive-Container -->           
    
    </div><!-- #banner -->