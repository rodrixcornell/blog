<?php if ( is_active_sidebar( 'home_right_1' ) ) : ?>
	<div id="sidebar">
		<?php dynamic_sidebar( 'home_right_1' ); ?>
	</div>
<?php endif; ?>