<div id="comments">

<div class="commentform"><?php comment_form(array('comment_notes_after' => '')); ?></div>

<ol class="commentlist"><?php wp_list_comments(array('style' => 'ol')); ?></ol>

</div>