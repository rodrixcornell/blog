<?php if ( is_active_sidebar( 'banner-1' ) ) : ?>
	<div id="banner">
		<?php dynamic_sidebar( 'banner-1' ); ?>
	</div>
<?php endif; ?>