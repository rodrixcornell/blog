Business Lite responsive WordPress theme
====================================

- Business Lite, Copyright 2013
- by CyberChimps http://cyberchimps.com
- Licensed under GNU General Public License v3.0 - http://www.gnu.org/licenses/gpl-3.0.html

- Bootstrap
- Adds core styles and responsive structure
- by Twitter Bootstrap http://getbootstrap.com/2.3.2/
- licensed under APLv2 - https://github.com/twitter/bootstrap/blob/master/LICENSE

- HTML5shiv
- adds HTML5 elements to browsers that are not HTML5 enabled
- https://code.google.com/p/html5shiv/
- Dual Licensed under MIT/GPL2 - http://opensource.org/licenses/mit-license.php / GNU General & Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html

- jCarousel
- adds the responsive Carousel
- by Sorgalla http://sorgalla.com/jcarousel/
- dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php) and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.

- Slimbox
- adds the lightbox we use in Portfolio etc
- by Digitalia http://www.digitalia.be/software/slimbox
- licensed under the MIT license - http://www.opensource.org/licenses/mit-license.php

- jQuery UI Touch Punch
- adds touch grag and drop and swipe functionality
- by David Furfero http://touchpunch.furf.com/
- dual licensed under the MIT or GPL Version 2 licenses.

- Retina.js v1.1.0
- adds the ability to load HD images to devices that can display them
- Copyright 2013 Imulus, LLC
- licensed under the MIT license

- Glyphicons
- fonticons for arrows, visual links etc
- http://http://glyphicons.com/
- licensed under APLv2 - https://github.com/twitter/bootstrap/blob/master/LICENSE

- Mono Social Icons Font
- adds social font icons
- http://drinchev.github.io/monosocialiconsfont/
- Licensed under SIL Open Font License

- All other images
- by CyberChimps http://cyberchimps.com
- Licensed under GNU General Public License v3.0 - http://www.gnu.org/licenses/gpl-3.0.html

====================================================================================================================================

For updated documentation, walkthroughs, and support please visit http://cyberchimps.com/

For updated docs please visit http://cyberchimps.com/guides/

For the support forum please visit: http://cyberchimps.com/forum/