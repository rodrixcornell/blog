;<?php exit; // do not remove ?>

[default]
; Database connection settings
; Database functionality is automatically disabled if any of these settings are blank.
; for available adapters see http://codeigniter.com/user_guide/database/configuration.html
;
dbdriver = mysql
hostname = localhost
database  = 
username = 
password = 
