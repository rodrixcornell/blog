<div id="TopMenuSocial">
<div class="socialfb"><a rel="nofollow" href="<?php echo esc_url(of_get_option('fb'));?>" alt="Facebook" target="_blank"></a></div>
<div class="socialyt"><a rel="nofollow" href="<?php echo esc_url(of_get_option('yt'));?>" alt="YouTube" target="_blank"></a></div>			
<div class="socialtw"><a rel="nofollow" href="<?php echo esc_url(of_get_option('tw'));?>" alt="Twitter" target="_blank"></a></div>
<div class="socialgp"><a  rel="nofollow" href="<?php echo esc_url(of_get_option('gp'));?>" alt="Google+" target="_blank"></a></div>
</div>