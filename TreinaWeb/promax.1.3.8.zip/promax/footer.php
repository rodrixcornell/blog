</div><!-- end div #page-inner -->
</div><!-- end div #page --><!-- END PAGE --><!-- BEGIN BOTTOM-MENU -->	
<?php load_template (get_template_directory() . '/includes/adfun.php'); ?><!-- end wrapper -->
<?php wp_footer(); ?>
</body>
</html>
