--------------------------------------------------------
Thanks for Downloading ProMax theme
--------------------------------------------------------
I made this for free to use if you find any bug or error please
You can directly contact us: http://www.wrock.org/promax
also suggestion are welcome


--------------------------------------------------------
How to Install theme: if you are getting any error or don't know intallation then read below tutorial
http://www.wrock.org/documentation-install-wordpress-premium-theme-without-data-loss/

--------------------------------------------------------

--------------------------ProMax------------------------
Features:

Theme have many features like some main are listed below

Theme option:
-upload favicon from theme option by url
-Customize you site backgroud color or image
-show 5 latest posts with thumbnail in right sidebar -activate from theme option > General settings
-enable search from theme option > General settings

Advertise:
-Add text link below navigation
-Ads supports single post and footer best for adsense

Social:
-Add you fan page or follow page of Facebook, twitter, Rss feed, Google+, Linkedin from theme option > Social Media

Custom Css:
-Also support for Custom Css with you have not need to change main style.css file


== Change log ==

= 1.3.8 =
*Updated Option Framework
*Fixed Logo and Banned ads issue
= 1.3.6 =
*Added shadow to posts make it stylish
*Font size customize
*Some premium features added
*Removed js folder no need of that in free version
*Fixed other issues

= 1.3 =
*Fixed thumbnail quality
*Footer copyright text update

= 1.2.3 =
*Fixed issue related home icon and categories 
*Theme Panel Change to new version
*Added wp_reset_postdata(); in latest and popular post

= 1.0 =
*Initial Release @ 1.0


== License ==

*Option Framework : Author is "Devin Price" provided at http://www.wptheming.com under License GPLv2 (All file Included in "inc" folder)
*For Responsive Menu Public code Used as ref. for http://wordpress.stackexchange.com/questions/74633/convert-wp-menu-to-a-drop-down-for-mobile-browser/98257
*Social Icons: are provided by "Konstantin Kovshenin" URL: http://kovshenin.com/2011/freebies-a-simple-social-icon-set-gpl/ Which in under GPL v2
*Images into /images/ folder that's are created by me abno.png, cat.png home.jpg, info.png, logo.png metaimg.png, quote.png, thumb.png are publish Under gpl v2
*Fonts Open Sans: Designed by Steve Matteson Director of Ascender Corp. Styled by: https://profiles.google.com/107777320916704234605/about License: Apache License, version 2.0 with GPL

**This theme and file are created by me & publish under GPLv3