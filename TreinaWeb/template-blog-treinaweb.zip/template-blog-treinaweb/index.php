<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Blog TreinaWeb</title>

    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Estilos -->

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">

    <!-- scripts -->

    <script type="text/javascript" src="js/modernizr.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>

  </head>

  <body>

    <!-- Container -->

    <div class="container">

      <!-- Barra de navegação -->


      <div class="navbar">
          <div class="navbar-inner">
            <div style="width: auto;" class="container">

              <!-- Opções de Menu -->

              <a href="#" class="brand">Blog TreinaWeb</a>
              <div class="nav-collapse">
                <ul class="nav">
                  <li class="active"><a href="#">Home</a></li>
                  <li><a href="#">Link 1</a></li>
                  <li><a href="#">Link 2</a></li>
                  <li><a href="#">Link3 </a></li>
                </ul>

                <!-- Formulário de pesquisa -->

                <form action="" class="navbar-search pull-left">
                  <input type="text" placeholder="Pesquisar" class="search-query span2">
                </form>

                <!-- Opções de menu -->

                <ul class="nav pull-right">
                  <li class="divider-vertical"></li>
                  <li class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">Opções <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                      <li><a href="#">Ação 1</a></li>
                      <li><a href="#">Ação 2</a></li>
                      <li><a href="#">Ação 3</a></li>
                      <li class="divider"></li>
                      <li><a href="#">Logout</a></li>
                    </ul>
                  </li>
                </ul>

              </div><!-- /.nav-collapse -->
            </div>
          </div><!-- /navbar-inner -->
        </div>

      <!-- Topo -->

      <div class="row-fluid">
          <div class="hero-unit">
            <h1>Nome do Blog</h1>
            <p>Boas vindas</p>
          </div>
      </div>

      <div class="row-fluid">

        <!-- sidebar -->

        <div class="span3">
          <div class="well sidebar-nav">

            <ul class="nav nav-list">

              <li class="nav-header">Posts recentes</li>
              <li class="active"><a href="#">Link</a></li>
              <li><a href="#">Link</a></li>
              <li><a href="#">Link</a></li>
              <li><a href="#">Link</a></li>

              <li class="nav-header">Arquivos</li>
              <li><a href="#">Link</a></li>
              <li><a href="#">Link</a></li>
              <li><a href="#">Link</a></li>
              <li><a href="#">Link</a></li>
              <li><a href="#">Link</a></li>
              <li><a href="#">Link</a></li>

              <li class="nav-header">Categorias</li>
              <li><a href="#">Link</a></li>
              <li><a href="#">Link</a></li>
              <li><a href="#">Link</a></li>

            </ul>
          </div><!--/.well -->
        </div><!--/span-->

        <!--/sidebar -->


        <!-- Posts -->

        <div class="span9">

            <!-- post -->

            <div class="row-fluid posts">

              <h2><a href="#">Título do Posts</a></h2>

              <p class="muted">
                <span>Publicado em</span>
                <a rel="bookmark" title="" href=""><span class="entry-date">21 de março de 2012</span></a>
              </p>

              <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>

              <p class="muted">
                <span>Categoria</span>
                <a rel="category" title="" href="">Assuntos Gerais</a>
              </p>

            </div>

            <!--/post -->

            <!-- post -->

            <div class="row-fluid posts">

              <h2><a href="#">Título do Posts</a></h2>

              <p class="muted">
                <span>Publicado em</span>
                <a rel="bookmark" title="" href=""><span class="entry-date">21 de março de 2012</span></a>
              </p>

              <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>

              <p class="muted">
                <span>Categoria</span>
                <a rel="category" title="" href="">Assuntos Gerais</a>
              </p>

            </div>

            <!--/post -->

        </div><!--/span9-->


      </div><!--/row-fluid-->

      <!-- Rodapé -->

      <hr>

      <footer>
        <p>&copy; TreinaWeb Cursos 2012</p>
      </footer>

    </div><!--/.fluid-container-->

  </body>
</html>
