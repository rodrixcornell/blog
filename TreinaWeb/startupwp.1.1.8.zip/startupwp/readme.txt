If you get into trouble at any point, we'll be in the forum to help you ASAP:

https://startupwp.com/forum/

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Documentation here:

https://startupwp.com/forum/documentation/

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

This theme is the free version of the professional theme found here:

https://startupwp.com/demo/

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

For a clear comparison chart of the differences between the free and pro versions, see:

https://startupwp.com/

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

While the pro theme has more options and features that allow you to have more advanced
control out-of-the-box, it's very important to understand that it is your right to use
this theme however you like. Under the GPL license we guarantee your right to hack,
edit, remove and alter the theme code/files (including our credit link) however you like.

See 'license.txt' for more licensing info.