<form method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
<div id="search-inputs">
<input type="submit" id="searchsubmit" value="Search" />
<input type="text" value="" name="s" id="s" />
</div>
</form>