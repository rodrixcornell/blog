=== Plugin Name ===
Contributors: povidiu
Author URI: http://www.avanguardia.ro
Plugin URI: http://www.avanguardia.ro
Tags: parole chiave, generatore pagine seo, generatore pagine, bulk page, bulk pages
Requires at least: 3.0.1
Stable tag: 1.0.0
Tested up to: 3.7.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Crea Landing Pages rapidamente utilizzando testo generico e parola chiave inserita automaticamente.

== Description ==

Questo plugin crea pagine wordpress con la parola chiave fornita nel titolo e corpo del testo. Permette di selettare pagine genitore, modello di pagina, i titoli delle pagine e contenuti.
Il numero totale di pagine create sarà il numero di righe immesse con la combinazione di città e lo stato in nome della città, stato (ad esempio: Parola1, Parola 2).

= SEO Tips =
Si consiglia la creazione di parole chiave mirate alla pagine, quindi personalizzare il contenuto di ogni pagina. Idealmente, più della metà del contenuto di una pagina di parole chiave dovrebbe essere unico per quella pagina e più di 500 parole di lunghezza.

Quando il Generatore pagine SEO crea una pagina, si aggiungerà un campo personalizzato per la keyword. È possibile utilizzare i modelli pagina per automatizzare il processo di personalizzazione con l'aggiunta di Google Maps, Meteo e altre localizzazione a una pagina.